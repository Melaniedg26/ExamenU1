class Carrera {
    constructor(id, nombre) {
      this.id = id;
      this.nombre = nombre;
      this.alumnos = []; // Lista de alumnos en la carrera
    }
  }
  
  module.exports = Carrera;