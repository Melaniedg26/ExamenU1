class Alumno {
    constructor(id, nombre) {
        this.id = id;
        this.nombre = nombre;
        this.carrera = null; // Inicialmente sin asignar a ninguna carrera
    }
}

module.exports = Alumno;
