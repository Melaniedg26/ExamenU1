class Venta {
    constructor(id, total, iva) {
        this.id = id;
        this.total = total;
        this.iva = iva;
    }
}

module.exports = Venta;